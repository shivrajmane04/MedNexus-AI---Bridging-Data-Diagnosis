import AIConsultation from '@/components/AIConsultation'
import React from 'react'

function VirtualAssistantPage() {
  return (
    <div>
        <AIConsultation />
    </div>
  )
}

export default VirtualAssistantPage